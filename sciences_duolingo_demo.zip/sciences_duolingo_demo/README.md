# Sciences — Démo style Duolingo (PWA)

Ce dossier est prêt à être mis en ligne tel quel (HTTPS). Deux options simples :

## Option A — Netlify Drop (le plus rapide)
1. Allez sur https://app.netlify.com/drop
2. Glissez-déposez **tout le dossier** ou **le ZIP**.
3. Netlify génère immédiatement une URL en HTTPS utilisable sur iPhone.

## Option B — GitHub Pages
1. Créez un dépôt (Public).
2. Ajoutez ces fichiers à la racine (`index.html`, `manifest.json`, `sw.js`, `icons/...`).
3. Réglages → Pages → Source: **Deploy from a branch** → Branch: `main` (root).
4. Ouvrez l’URL fournie par GitHub Pages (HTTPS).

## iPhone — Ajouter à l’écran d’accueil
1. Ouvrez l’URL dans Safari sur iPhone.
2. Partager → **Ajouter à l’écran d’accueil**.
3. L’app s’ouvre en plein écran hors ligne (PWA) et garde votre progression.
